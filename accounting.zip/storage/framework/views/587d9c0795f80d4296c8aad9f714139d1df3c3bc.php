<footer class="main-footer d-flex p-2 px-3 bg-white border-top">
    <span class="copyright ml-auto my-auto mr-2">Copyright © 2019 DesignRevision</span>
</footer><?php /**PATH C:\xampp\htdocs\Nayem\accounting\resources\views/inc/footer.blade.php ENDPATH**/ ?>