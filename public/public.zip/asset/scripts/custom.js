$(document).ready(function() {
    $('.single-select').select2({
        placeholder: 'Select an option'
    });
});
